login_locator = 'a.nav__button-secondary'
pwd_locator = 'input#password'
show_pwd_locator = 'span#password-visibility-toggle'
search_locator = 'input.search-global-typeahead__input.always-show-placeholder'
companies_locator = '.entity-result__title-text a'

select_bar_xpath = '//*[@d="M8 11L3 6h10z"]'