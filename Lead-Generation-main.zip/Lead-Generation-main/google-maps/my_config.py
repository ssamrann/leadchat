google_maps = 'https://www.google.ru/maps'

order = {
    'Title': None,
    'Address': 'place_gm_blue_24dp.png',
    'WebSite': 'public_gm_blue_24dp.png',
    'PhoneNumber': 'phone_gm_blue_24dp.png'
}
