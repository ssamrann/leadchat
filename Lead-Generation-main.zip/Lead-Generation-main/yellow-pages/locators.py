results_xpath = '//*[@class=" leftRailSearchResultsContainer__09f24__3vlwA border-color--default__09f24__R1nRO"]'
next_xpath = '//*[@class="icon--24-chevron-right-v2 navigation-button-icon__09f24__2FnZH css-12anxc3"]'
places_xpath = '//h4'
inner_xpath = '//section[@class=" margin-b3__373c0__q1DuY border-color--default__373c0__3-ifU"]'

search_button_selector = '.ybtn.ybtn--primary.ybtn--small.business-search-form_button'
input_selector = '.pseudo-input_field.business-search-form_input-field'

json_attrs = {'type': 'application/ld+json'}
website_attrs = {'target': '_blank'}
